package com.inditex.psadstproc;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringJoiner;
import java.util.UUID;

public class MainClass {

  public interface ClientService {
    public Client save(String name, String carDescription) throws IOException;
  }

  public class ClientServiceImpl implements ClientService {

    @Override
    public Client save(final String name, final String carDescription) throws IOException {
      final var client = new Client(UUID.randomUUID(), name, carDescription);
      final BufferedWriter writer = new BufferedWriter(new FileWriter("/Users/lucas/Desktop/client"));
      writer.write(client.toString());
      writer.close();
      return client;
    }
  }

  public class Client {
    private final UUID id;

    private final String name;

    private final String carDescription;

    public Client(final UUID id, final String name, final String carDescription) {
      this.id = id;
      this.name = name;
      this.carDescription = carDescription;
    }

    public UUID getId() {
      return this.id;
    }

    public String getName() {
      return this.name;
    }

    public String getCarDescription() {
      return this.carDescription;
    }

    @Override
    public String toString() {
      return new StringJoiner(", ", Client.class.getSimpleName() + "[", "]")
          .add("id=" + this.id)
          .add("name='" + this.name + "'")
          .add("carDescription='" + this.carDescription + "'")
          .toString();
    }
  }

}
