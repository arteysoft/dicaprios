import java.io.IOException;
import java.util.Scanner;

import com.inditex.psadstproc.MainClass;
import com.inditex.psadstproc.MainClass.ClientService;

public class Main {

  public static void main(final String[] args) throws IOException {

    final Scanner clientName = new Scanner(System.in);
    System.out.println("Enter clientName");

    final String clientNameString = clientName.nextLine();

    final Scanner carDescription = new Scanner(System.in);
    System.out.println("Enter car desc");

    final String carDescString = carDescription.nextLine();

    final MainClass mainClass = new MainClass();

    final ClientService service = mainClass.new ClientServiceImpl();

    service.save(clientNameString, carDescString);

  }

}
