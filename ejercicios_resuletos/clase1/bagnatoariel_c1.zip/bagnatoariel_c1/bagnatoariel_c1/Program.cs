﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bagnatoariel_c1
{
    class Program
    {
        static void Main(string[] args)
        {
            personaauto pa = new personaauto();
            pa.id.GetHashCode();
            pa.Nombre = "Ariel Bagnato";
            pa.Auto = "Dodge Journey";

            Console.WriteLine($"ID: {pa.id} - Nombre: {pa.Nombre} - Auto: {pa.Auto}");
            StreamWriter sw = new StreamWriter("Test.txt");
            sw.WriteLine($"ID: {pa.id} - Nombre: {pa.Nombre} - Auto: {pa.Auto}");
            sw.Close();
            Console.ReadKey();

        }   
    }
}
