﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bagnatoariel_c1
{
    public class personaauto
    {
        public Guid id { get; set; }
        public string Nombre { get; set; }

        public string Auto { get; set; }
    }
}
