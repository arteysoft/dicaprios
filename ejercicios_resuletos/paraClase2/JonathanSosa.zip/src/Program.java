import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Ingrese su nombre:");
		String nombre = sc.nextLine();
		
		System.out.println("Ingrese la marca de su vehiculo:");
		String marca = sc.nextLine();
		
		System.out.println("Ingrese el modelo de su vehiculo:");
		String modelo = sc.nextLine();
		
		Auto auto = new Auto(marca, modelo);
		Cliente cliente = new Cliente(nombre, auto);
		
		System.out.println("El cliente es: ".concat(cliente.getNombre()));
		System.out.println("y su vehiculo es: ".concat(cliente.getNombreAuto()));
		System.out.println("presione una tecla para terminar el programa...");
		sc.nextLine();
		sc.close();
	}

}
